@extends('layouts.user-layout')
@section('konten')
<!-- CONTENT =============================-->
<section class="item content">
    <div class="container toparea">
        <div class="underlined-title">
            <div class="editContent">
                <h1 class="text-center latestitems">Keranjang Anda</h1>
            </div>
            <div class="wow-hr type_short">
                <span class="wow-hr-h">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </span>
            </div>
        </div>
        @if(Session::has('success'))
        <div class="alert alert-success">
            {{Session::get('success')}}
        </div>
        @endif
        @if(sizeof($product)>0)
        @foreach ($product as $p)
        <div class="row" style="margin-bottom: 10px;">
            <div class="col-12 col-md-4 col-lg-4">
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <div class="card-body">
                            <center>
                                @foreach ($p->produk[0]->RelasiProductImage as $gambar)
                                @if ($loop->iteration == 1)
                                <img src="{{asset('img/'.$gambar->image_name)}}" alt="" width="200" height="200"></span>
                                @endif
                                @endforeach
                            </center>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-8 col-lg-4">
                @foreach($p->produk as $pro)
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <p class="text-primary font-weight-bold h2 ">{{$pro->product_name}}</p>
                        <p class="text-success h4">Rp.{{number_format($pro->price)}}</p>
                        <hr style="border-top: thin solid #000000;width:100%; text-align:left;margin-left:0; margin-top: 13px; margin-bottom: 13px;">

                        <p>Deskripsi : {{$pro->description}}<br>Berat : {{$pro->weight}} gram<br>Jumlah : {{$p->qty}}</p>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="col-lg-4">
                <div class="pull-right">
                    <button data-toggle="modal" data-target="#modalku{{$p->id}}" class="btn btn-success"><i class="fa fa-edit"></i>Ubah</button>
                    <div class="modal fade" id="modalku{{$p->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h5 class="modal-title" id="exampleModalLabel">Form Jumlah</h5>
                                </div>
                                <form action="{{ route('ubahjumlah') }}" method="post">
                                    @csrf
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="{{$p->id}}">
                                        <div class="form-group">
                                            <label>Jumlah</label>
                                            <input type="number" name="qty" class="form-control" value="{{$p->qty}}" min="1" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Ubah</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <a class="btn btn-danger" href="{{ route('hapuscart', ['id' => $p->id]) }}" onclick="return confirm('Yakin melanjutkan hapus data ? ')"><i class="fa fa-trash"></i>Hapus</a>
                </div>
            </div>
        </div>
        @endforeach
        @else
        <div class="alert alert-danger">Ups Keranjang Anda Masih Kosong</div>
        @endif
        <div class="col-lg-12" style="text-align: center; padding-top: 20px;">
            @if(sizeof($product)>0)
            <button class="btn btn-primary" data-toggle="modal" data-target="#checkout">Checkout</button>
            <div class="modal fade" id="checkout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Data Checkout</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="post" action="{{ route('post.checkout')}}">
                            @csrf
                            <div class="modal-body">
                                <div class="form-group" style="text-align: left;">
                                    <label>Alamat</label>
                                    <input type="text" name="alamat" class="form-control" placeholder="Masukkan alamat" required>
                                </div>
                                <div class="form-group" style="text-align: left;">
                                    <label>Provinsi</label>
                                    <input type="text" name="prov" class="form-control" placeholder="Masukkan provinsi" required>
                                </div>
                                <div class="form-group" style="text-align: left;">
                                    <label>Kota / Kabupaten</label>
                                    <input type="text" name="kab" class="form-control" placeholder="Masukkan kota / kabupaten" required>
                                </div>
                                <div class="form-group" style="text-align: left;">
                                    <label>Kurir</label>
                                    <select class="form-control" name="kurir" required>
                                        <option value="">--Select Here--</option>
                                        @foreach($courier as $cou)
                                        <option value="{{$cou->id}}">{{$cou->courier}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Checkout</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
</div>
</section>

<!-- CALL TO ACTION =============================-->
<section class="content-block" style="background-color:#00bba7;">
    <div class="container text-center">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1">
                <div class="item" data-scrollreveal="enter top over 0.4s after 0.1s">
                    <h1 class="callactiontitle"> Promote Items Area Give Discount to Buyers <span
                        class="callactionbutton"><i class="fa fa-gift"></i> WOW24TH</span>
                    </h1>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection