@extends('component.admin-layout')

@section('content')
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-light">Laporan Pertahun</div>

                <div class="card-body">
                    <form action="/laporan/pertahun" method="get" style="margin-bottom: 15px">
                        <div class="row">
                            <div class="col-lg-12" style="padding-right: 0; margin-bottom: 5px;">
                                <label>Tahun</label>
                                <input type="number" name="tahun" min="1990" class="form-control" value="{{$tahun}}">
                            </div>
                            <div class="col-lg-12" style="text-align: center; padding-top: 10px">
                                <input type="submit" class="btn btn-primary"  value="Lihat" />
                            </div>
                        </div>
                    </form>
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th class="text-center">No.</th>
                                <th class="text-center">Bulan</th>
                                <th class="text-center">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(sizeof($laporan) > 0)
                            @foreach($laporan as $lap)
                            <tr>
                                <td class="text-center">{{$loop->iteration}}</td>
                                <td class="text-center">
                                    @if($lap->bulan == 1)
                                    Januari
                                    @elseif($lap->bulan == 2)
                                    Februari
                                    @elseif($lap->bulan == 3)
                                    Maret
                                    @elseif($lap->bulan == 4)
                                    April
                                    @elseif($lap->bulan == 5)
                                    Mei
                                    @elseif($lap->bulan == 6)
                                    Juni
                                    @elseif($lap->bulan == 7)
                                    Juli
                                    @elseif($lap->bulan == 8)
                                    Agustus
                                    @elseif($lap->bulan == 9)
                                    September
                                    @elseif($lap->bulan == 10)
                                    Oktober
                                    @elseif($lap->bulan == 11)
                                    November
                                    @elseif($lap->bulan == 12)
                                    Desember
                                    @endif
                                </td>
                                <td class="text-center">{{$lap->jumlah}}</td>
                            </tr>
                            @endforeach
                            @else
                            <tr>
                                <td colspan="3" style="text-align: center;">Tidak ada data</td>
                            </tr>
                            @endif
                        </tbody>
                    </table>
                    <div style="margin-top: 15px">
                        <canvas id="myChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    function getbulan(param){
        if (param == 1) {
            return "Januari"
        }else if (param == 2) {
            return "Februari"
        }else if (param == 3) {
            return "Maret"
        }else if (param == 4) {
            return "April"
        }else if (param == 5) {
            return "Mei"
        }else if (param == 6) {
            return "Juni"
        }else if (param == 7) {
            return "Juli"
        }else if (param == 8) {
            return "Agustus"
        }else if (param == 9) {
            return "September"
        }else if (param == 10) {
            return "Oktober"
        }else if (param == 11) {
            return "November"
        }else if (param == 12) {
            return "Desember"
        }
    }

    var laporan = <?php echo $laporan ?>;
    var label = [], data=[];
    for (var i = 0; i < laporan.length; i++) {
        label.push(getbulan(laporan[i].bulan));
        data.push(laporan[i].jumlah);
    }
    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: label,
            datasets: [{
                label: 'jumlah transaksi',
                data: data,
                backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
@endsection
