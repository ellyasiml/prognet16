@extends('component.admin-layout')

@section('content')
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-light">Laporan Perbulan</div>

                <div class="card-body">
                    <form action="/laporan/perbulan" method="get" style="margin-bottom: 15px">
                        <div class="row">
                            <div class="col-lg-6" style="padding-left: 0; margin-bottom: 5px;">
                                <label>Bulan</label>
                                <select class="form-control" name="bulan">
                                    <option value="">--Select Here--</option>
                                    <option @if($bulan == 1){{'selected'}}@endif value="1">Januari</option>
                                    <option @if($bulan == 2){{'selected'}}@endif value="2">Februari</option>
                                    <option @if($bulan == 3){{'selected'}}@endif value="3">Maret</option>
                                    <option @if($bulan == 4){{'selected'}}@endif value="4">April</option>
                                    <option @if($bulan == 5){{'selected'}}@endif value="5">Mei</option>
                                    <option @if($bulan == 6){{'selected'}}@endif value="6">Juni</option>
                                    <option @if($bulan == 7){{'selected'}}@endif value="7">Juli</option>
                                    <option @if($bulan == 8){{'selected'}}@endif value="8">Agustus</option>
                                    <option @if($bulan == 9){{'selected'}}@endif value="9">September</option>
                                    <option @if($bulan == 10){{'selected'}}@endif value="10">Oktober</option>
                                    <option @if($bulan == 11){{'selected'}}@endif value="11">November</option>
                                    <option @if($bulan == 12){{'selected'}}@endif value="12">Desember</option>
                                </select>
                            </div>
                            <div class="col-lg-6" style="padding-right: 0; margin-bottom: 5px;">
                                <label>Tahun</label>
                                <input type="number" name="tahun" min="1990" class="form-control" value="{{$tahun}}">
                            </div>
                            <div class="col-lg-12" style="text-align: center; padding-top: 10px">
                                <input type="submit" class="btn btn-primary"  value="Lihat" />
                            </div>
                        </div>
                    </form>
                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th class="text-center">No.</th>
                                <th class="text-center">Tanggal</th>
                                <th class="text-center">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(sizeof($laporan) > 0)
                            @foreach($laporan as $lap)
                            <tr>
                                <td class="text-center">{{$loop->iteration}}</td>
                                <td class="text-center">{{date('d-m-Y', strtotime($lap->tanggal))}}</td>
                                <td class="text-center">{{$lap->jumlah}}</td>
                            </tr>
                            @endforeach
                            @else
                            <tr>
                                <td colspan="3" style="text-align: center;">Tidak ada data</td>
                            </tr>
                            @endif
                        </tbody>
                    </table>
                    <div style="margin-top: 15px">
                        <canvas id="myChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var laporan = <?php echo $laporan ?>;
    var label = [], data=[];
    for (var i = 0; i < laporan.length; i++) {
        label.push(laporan[i].tanggal);
        data.push(laporan[i].jumlah);
    }
    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: label,
            datasets: [{
                label: 'jumlah transaksi',
                data: data,
                backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
@endsection
