<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Courier extends Model
{
    
   //Nama Tabel Yang digunakan dalam SQL
   protected $table = 'couriers';
}
