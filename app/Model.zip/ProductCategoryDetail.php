<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCategoryDetail extends Model
{
    //Nama Tabel Yang digunakan dalam SQL
    protected $table = 'product_category_details';
    
}
