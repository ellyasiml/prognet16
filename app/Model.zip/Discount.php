<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Discount extends Model
{
    //Nama Tabel Yang digunakan dalam SQL
    protected $table = 'discounts';
}