<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Product;
class ProductImage extends Model
{
    //Nama Tabel yang digunakan di SQL
    protected $table ='product_images';
}
